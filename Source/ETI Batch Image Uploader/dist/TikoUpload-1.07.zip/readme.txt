LL Batch Uploader
by Tiko!!

You have to have the Java Runtime thing 1.5 or higher to run this, which shouldn't be a problem.
It requires your LL cookie, which I don't steal. Sniff the packets or decompile the program if you want! For help on getting this, click the ? button from the program's GUI.

You can get the latest java at: www.java.com

Troubleshooting
Q. wtf my image has a URL but it shows up as a red X ???
A. the image was probably too big for LL, i think the maximum is somewhere around 1.5mb

Q. isn't this botting LL??? that's bannable!!!
A. not really, it only hits the upload page, it doesn't even hit the page that gives the links! it takes up less bandwidth than doing it yourself!
   
   in fact, this is llamaguy approved!
   
   From: LlamaGuy | Posted: 7/29/2007 04:59:18 PM | Filter | Message Detail
   That's pretty cool actually.